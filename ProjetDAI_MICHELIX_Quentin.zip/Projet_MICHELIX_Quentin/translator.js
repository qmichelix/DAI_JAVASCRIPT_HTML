"use strict";

// Demande le lancement de l'exécution quand toute la page Web sera chargée
window.addEventListener('load', go);

// SAM Design Pattern : http://sam.js.org/
let actions, model, state, view;

//-------------------------------------------------------------------- Init ---
let aux1=0;
let aux2=1;
let aux3=false;
let aux4=0;
let auxi=1;
let auxj=0;

// Point d'entrée de l'application
function go() {
	console.log('GO !');

	for (let i=0;i<9;i++){
		structure.push(false);
	}
	trad=translations1;

	sandbox();

	const data = {
		authors: '\nTraducteur - Application Web\n\nAuteur(s) : MICHELIX Quentin',
		languagesSrc: ['fr', 'en', 'es'],
		languagesDst: ['fr', 'en', 'es', 'it', 'ar', 'eo', 'ja', 'zh'],
		langSrc: 'fr',
		langDst: 'en',
		translations : trad.slice(),
	};
	actions.initAndGo(data);
}

//-------------------------------------------------------------------- Tests ---

function sandbox() {

  function action_display(data) {
		// console.log(data);
    if (!data.error) {
      const language = languages[data.languageDst].toLowerCase();
      console.log(`'${data.expression}' s'écrit '${data.translatedExpr}' en ${language}`);
		}
		else{
			console.log('Service de traduction indisponible...');
		}
	}

  const expr = 'asperge';
  const langSrc = 'fr';
  const langDst = 'en';
  googleTranslation(expr, langSrc, langDst, action_display );
}

//------------------------------------------------------------------ Données ---

// Correspondance entre codes de langue et leur nom
// Pour d'autres langues, voir ici :  https://fr.wikipedia.org/wiki/Liste_des_codes_ISO_639-1
const languages = {
  fr: 'Français',
  en: 'Anglais',
  es: 'Espagnol',
  it: 'Italien',
  ar: 'Arabe',
  eo: 'Espéranto',
  ja: 'Japonais',
  zh: 'Chinois',
};

//------------------------------------------------------------------ Actions ---
// Actions appelées dans le code HTML quand des événements surviennent
//

actions = {
  initAndGo(data) {
    model.samPresent({
      do:'init',
      authors: data.authors,
      langSrc: data.langSrc,
      langDst: data.langDst,
      languagesSrc: data.languagesSrc,
      languagesDst: data.languagesDst,
      translations: data.translations,
	  	NombreDeMotParPages: 6,
	  	NombreDePages: 1,
	  	NumeroDePage: 1,
		});
	},

	about() {alert(model.app.authors);
	},
  traduction(){
	  if(document.getElementById("expressionText").value!=""){
		model.samPresent({
		  do:'traduction',
		  translations: trad,
		  depuis: document.getElementById("selectFrom").value,
		  vers: document.getElementById("selectTo").value,
		  chemin: document.getElementById("expressionText").value,
		});
	}
},

	MethodePourLeTri(id){
		model.samPresent({
			do:'tri',
			translations: trad.slice(),
			id: id,
			languagesDst: ['fr', 'en', 'es', 'it', 'ar', 'eo', 'ja', 'zh'],
		});
	},

  Refresh1(src,dst){
	  model.samPresent({
		  do:'Refresh1',
		  translations: trad,
		  depuis: document.getElementById("selectFrom").value,
		  vers: document.getElementById("selectTo").value,
		  chemin: src,
		  juste: dst,
		  languagesDst: ['fr', 'en', 'es', 'it', 'ar', 'eo', 'ja', 'zh'],
		});
	},

  Refresh2(NombreDeMotParPages,NumeroDePage){
	  model.samPresent({
		  do:'Refresh2',
		  translations: trad.slice(),
		  NombreDeMotParPages: NombreDeMotParPages,
		  NumeroDePage: NumeroDePage,
		});
	},

	ChangementL(lien){
		model.samPresent({
			do:'appuyer',
			ChangementL2: lien,
			translations: trad.slice(),
			languagesDst: ['fr', 'en', 'es', 'it', 'ar', 'eo', 'ja', 'zh'],});},};

	let trad;
	let translated;
	let nbPageIndice=1;
	let numeroPage=1;
	let structure=[];
	let switchnombre=false;

function EffectuerTri(tab,param1){
	let aux0;
	let aux5;
	let aux6;
	let aux;

	if(param1!=1){
		if(param1==3||param1==5){aux5='traduction';
	}
		if(param1==2||param1==4){aux5='langue';
	}
		if(param1==3||param1==2){aux6='deb';
	}
		if(param1==5||param1==4){aux6='fin';
	}
		for(let i=0;i<tab.length-1;i++){
			aux0=i;
			for(let j=i+1;j<tab.length;j++){
				if(view.verif(tab[j],tab[j][param1-2],aux5,aux6,model.tabs.tabs2)<view.verif(tab[aux0],tab[aux0][param1-2],aux5,aux6,model.tabs.tabs2)){
					aux0=j;
				}
			}
				if(aux0!=i){
				aux=tab[i];
				tab[i]=tab[aux0];
				tab[aux0]=aux;
			}
		}
	}
				else {
				Swap(tab);
				switchnombre=true;
			}
				if (aux4==param1&&aux3){
					Swap(tab);
					aux3=false;
					switchnombre=false;
				}
				else{
					aux3=true;
				}
					aux4=param1;
				}

function Swap(tab){
	let aux;
	for(let i=0;i<Math.floor(tab.length/2);i++){
		aux=tab[i];
		tab[i]=tab[tab.length-i-1];
		tab[tab.length-i-1]=aux;
	}
}

function Swappage(num){
	let i=0;
	structure[num]=!structure[num];
	while(i<structure.length&&!structure[i]){
		i++;
	}
	if(i<structure.length){
		document.getElementById("destroy").className="btn btn-secondary";
		document.getElementById("destroy").setAttribute("onclick","deleteOnep(model.tabs.tabs2)");
	}
	else{
		document.getElementById("destroy").className="btn btn-ternary";
	}
}

	function TestTableau(valeurs,langues){
		let i=0;
		let max;
		let aux;
		let leTab=[['trad',valeurs.length]];
		while(i<langues.length){
			let compteur=0;
			let j=0;
			while(j<valeurs.length){
				if(langues[i]==valeurs[j][0]){
					compteur++;
				}
				if(langues[i]==valeurs[j][2]){
					compteur++;
				}
				j++;
			}
			leTab.push([langues[i],compteur]);
			i++;
		}
		for(i=1;i<langues.length;i++){
			max=i;
			for(let j=i+1;j<langues.length+1;j++){
				if(leTab[j][1]>leTab[max][1]){
					max=j;
				}
			}
			if(max!=i){
				aux=leTab[i];
				leTab[i]=leTab[max];
				leTab[max]=aux;
			}
		}
		return leTab;
	}

	function changement(param4){
		let res;
		switch (param4) {
			case 'trad': res='';break;
			case 'fr': res='Français';	break;
			case 'en': res='Anglais';		break;
			case 'es': res='Espagnol';	break;
			case 'it': res='Italien';		break;
			case 'ar': res='Arabe';			break;
			case 'eo': res='Espéranto';	break;
			case 'ja': res='Japonais';	break;
			case 'zh': res='Chinois';		break;
		}
		return res;
	}

function switchpage(){
	let taillePage=document.getElementById("selectPage").value;
	nbPageIndice=document.getElementById("selectPage").selectedIndex;
	numeroPage=1;
	actions.Refresh2(taillePage,numeroPage);
}

function switchnumpage(leNum){
	let taillePage=document.getElementById("selectPage").value;
	numeroPage=leNum;
	actions.Refresh2(taillePage,numeroPage);
}

function switchtrue(){
	let i=0;
	let j=0;
	let aux11=document.getElementById("selectFrom").value;
	let aux12=document.getElementById("selectTo").value;
	if(aux12!=aux11){
		document.getElementById("tradButton").disabled=false;
		while(i<document.getElementById("selectFrom").options.length&&document.getElementById("selectFrom").options[i].value!=aux12){
			i++;
		}
		if(i<document.getElementById("selectFrom").options.length){
			while(j<document.getElementById("selectTo").options.length&&document.getElementById("selectTo").options[j].value!=aux11){
				j++;
			}
			if(j<document.getElementById("selectTo").options.length){
				auxi=i;
				auxj=j;
				document.getElementById("invButton").disabled=false;
			}
			else{document.getElementById("invButton").disabled=true;
		}
	}
			else{document.getElementById("invButton").disabled=true;
		}
	}
			else{document.getElementById("invButton").disabled=true;document.getElementById("tradButton").disabled=true;
		}
		aux1=document.getElementById("selectFrom").selectedIndex;aux2=document.getElementById("selectTo").selectedIndex;
	}

function doubleswitch(){
	let aux;
	document.getElementById("selectFrom").selectedIndex=auxi;
	document.getElementById("selectTo").selectedIndex=auxj;
	aux=auxj;
	auxj=auxi;
	auxi=aux;
	aux1=document.getElementById("selectFrom").selectedIndex;
	aux2=document.getElementById("selectTo").selectedIndex;
}

function find(tabs2,valeurs){
	let i=0;
	while(i<valeurs.length&&tabs2!=valeurs[i][0]){
		i++;
	}
	if(i<valeurs.length){
		return i;
	}
	return 0;
}

function diff(a,b){
	if(a==b||(a==''&&b=='trad')){
		return ` active`;
	}
	return ``;
}

function tri(valeurs,tabs2){
	let i=0;
	let val=valeurs;
	while(i<val.length){
		if(val[i][0]!=tabs2&&val[i][2]!=tabs2){
			val.splice(i,1);
			i--;
		}
		i++;
	}
	return val;
}

function deleteOnep(langue){
switchnombre=false;
aux4=0;
aux3=false;
let i=0;
let j=0;
while(i<structure.length){
	if(structure[i]==true){
		trad.splice(i-j,1)
		structure[i]=false;
		j++;
	}
	i++;
}
i=0;
while(i<trad.length){
	trad[i][4]=i;
	i++;
}
	if(j<model.translations.values.length){
	actions.ChangementL(langue);
	}
	else{
	actions.ChangementL('trad');
	}
}

function deleteAll(langue){
let i=0;
let texte='Êtes-vous sûr de vouloir supprimer toutes les traductions ';
if(langue=='trad'){
	texte+='?';
}
else{
	texte+='en '+changement(langue).toLowerCase()+' ?';
}
if(confirm(texte)){
	switchnombre=false;
	aux4=0;
	aux3=false;
	if(langue=='trad'){
		trad=[];
	}
	else{
		while(i<trad.length){
			if(trad[i][0]==langue||trad[i][2]==langue){
				trad.splice(i,1);
				i--;
			}
			i++;
		}
		i=0;
		while(i<trad.length){
			trad[i][4]=i;
			i++;
		}
	}
	actions.ChangementL('trad');
	}
}

function action_display2(data) {
    if (!data.error) {
      const language = languages[data.languageDst].toLowerCase();
      console.log(`'${data.expression}' s'écrit '${data.translatedExpr}' en ${language}`);
	  translated=data.translatedExpr;
    }
		else {
	  translated=data.expression;
      console.log('Service de traduction indisponible...');
    }
		actions.Refresh1(data.expression.toLowerCase(),data.translatedExpr.toLowerCase());
	}

//-------------------------------------------------------------------- Model ---
// Unique source de vérité de l'application
//
model = {
	tabs: {
		values:[

		],
	tabs2: '',
	},
	request: {
		languagesSrc: [],
		languagesDst: [],
		langSrc: '',
		langDst: '',
		expression: '',
	},
	translations: {
		values:[
		],
	},
	sorted: {
	},
	marked: {
	},
	pagination: {
		NumeroDePage: 1,
		NombreDePages: 1,
		taillePage: 6,
	},
	app: {
		authors: '',
		mode: 'main',
		sectionId: 'app',
	},

// Demande au modèle de se mettre à jour en fonction des données qu'on
// lui présente.
// l'argument data est un objet confectionné dans les actions.
// Les propriétés de data comportent les modifications à faire sur le modèle.
	samPresent(data) {

    switch (data.do) {

      case 'init':
        this.app.authors = data.authors;
        this.request.languagesSrc = data.languagesSrc;
        this.request.languagesDst = data.languagesDst;
        this.request.langSrc = data.langSrc;
        this.request.langDst = data.langDst;
        this.translations.values = data.translations;
		this.tabs.values=TestTableau(data.translations,data.languagesDst);
		this.tabs.tabs2='trad';
		this.pagination.NumeroDePage=data.NumeroDePage;
		this.pagination.NombreDePages=data.NombreDePages;
		this.pagination.taillePage=data.NombreDeMotParPages;
        break;

      case 'appuyer':
	    this.translations.values = data.translations;
		if(data.ChangementL2=='select'){
			data.ChangementL2=document.getElementById("selectForm").value;
		}
		this.tabs.values=TestTableau(this.translations.values,data.languagesDst);
	    this.tabs.tabs2=data.ChangementL2;
		break;

	  case 'traduction':
		googleTranslation(data.chemin,data.depuis,data.vers,action_display2);
		break;

	  case 'Refresh1':
		data.translations.push([data.depuis,data.chemin,data.vers,data.juste,trad.length]);
		this.translations.values=data.translations.slice();
		this.tabs.values=TestTableau(this.translations.values,data.languagesDst);
		this.tabs.tabs2='trad';
		break;

	  case 'Refresh2':
		this.translations.values=data.translations;
		this.pagination.NumeroDePage=data.NumeroDePage;
		this.pagination.taillePage=data.NombreDeMotParPages;
		break;

	  case 'tri':
	    this.translations.values = data.translations;
		this.tabs.values=TestTableau(this.translations.values,data.languagesDst);
		EffectuerTri(this.translations.values,data.id);
		break;

      default:
      console.error(`model.samPresent(), unknown do: '${data.do}' `);
		}
// Demande à l'état de l'application de prendre en compte la modification
// du modèle
			if(data.do!='traduction'){
				state.samUpdate(this);
			}
		},
	};

//-------------------------------------------------------------------- State ---
// État de l'application avant affichage
//
state = {
	tabs: {
	},
	translations: {
		values:[
		],},
	samUpdate(model){this.samRepresent(model);
	},
	samRepresent(model) {
		if(model.tabs.tabs2!='trad'){this.translations.values=tri(model.translations.values,model.tabs.tabs2);
		}
		else{this.translations.values=model.translations.values;
		}
		model.pagination.NombreDePages=Math.ceil(this.translations.values.length/model.pagination.taillePage);
		if(model.pagination.NumeroDePage>model.pagination.NombreDePages){model.pagination.NumeroDePage = 1;numeroPage=1;
		}
		let representation = '';
		let headerUI = view.headerUI(model,state);
		let paginationUI = view.paginationUI(model.pagination);
		let tableauUI = view.tableauUI(this.translations.values,model.pagination.taillePage,model.pagination.NumeroDePage,model.tabs.tabs2);
		let ongletsUI = view.ongletsUI(model.tabs.tabs2=='trad',model.tabs.tabs2);
		representation += headerUI;
		representation += ongletsUI;
		representation += tableauUI;
		representation += paginationUI;
		representation = view.generateUI(model, this, representation);
		view.samDisplay(model.app.sectionId, representation);
		if(model.tabs.tabs2=='trad'){
			document.getElementById("selectFrom").selectedIndex=aux1;
			document.getElementById("selectTo").selectedIndex=aux2;
			switchtrue();
		}
		document.getElementById("selectPage").selectedIndex=nbPageIndice;
	},
};

//--------------------------------------------------------------------- View ---
// Génération en HTML et affichage
//
view = {

// Injecte le HTML dans une balise de la page Web.
	samDisplay(eltId, representation) {
		const elt = document.getElementById(eltId);
		elt.innerHTML = representation;
	},

// Renvoit le HTML
	generateUI(model, state, representation) {
		return `
		<div class="container">
		${representation}
		</div>
		`;
	},

	SauvergardeBouton(valeurs,tabs2){
		let i=1;
		let lim=3;
		let indice=-1;
		let texte=``;
		if(tabs2!='trad'){
			indice=find(tabs2,valeurs);
			texte+=`
				<li class="nav-item">
					<a class="nav-link active" onclick="actions.ChangementL('`+valeurs[indice][0]+`')" href="#">`+changement(valeurs[indice][0])+`
						<span class="badge badge-primary">`+valeurs[indice][1]+`</span>
					</a>
				</li>`;
			}
		else{lim++;
		}
		while(i<lim&&valeurs[i][1]>0){
			if(tabs2==valeurs[i][0]){
				lim++;
			}
			else{
				texte+=`
					<li class="nav-item">
						<a class="nav-link`+diff(tabs2,valeurs[i][0])+`" onclick="actions.ChangementL('`+valeurs[i][0]+`')" href="#">`+changement(valeurs[i][0])+`
							<span class="badge badge-primary">`+valeurs[i][1]+`</span>
						</a>
					</li>`;
				}i++;
			}
		texte=`
		<li class="nav-item">
            <a class="nav-link`+diff(tabs2,'trad')+`" onclick="actions.ChangementL('trad')"
              href="#">Traductions
              <span class="badge badge-primary">`+valeurs[0][1]+`</span>
            </a>
          </li>
		  `+texte;
		texte+=`
		<li class="nav-item">
            <select class="custom-select" id="selectForm" onchange="actions.ChangementL('select')">
              <option selected="selected" value="0">Autre langue...</option>`;
        while(i<valeurs.length&&valeurs[i][1]>0){
			if(tabs2!=valeurs[i][0]){
				texte+=`
				<option value="`+valeurs[i][0]+`">`+changement(valeurs[i][0])+` (`+valeurs[i][1]+`)</option>`;
			}i++;
		}texte+=`</select></li>`;return texte;
			},

	headerUI(model,state) {
		return (`
    <section id="header" class="mt-4">
      <div class="row mb-4">
        <div class="col-6">
          <h1>Traducteur</h1>
        </div>
		<div class="col-6 text-right align-middle">
          <div class="btn-group mt-2">
            <button class="btn btn-primary">Charger</button>
            <button class="btn btn-ternary">Enregistrer</button>
            <button class="btn btn-secondary">Préférences</button>
            <button class="btn btn-primary" onclick="actions.about()">À propos</button>
          </div>
        </div>
      </div>
    </section>
	<section id="tabs">
      <div class="row justify-content-start ml-1 mr-1">
        <ul class="nav nav-tabs">
          `+this.SauvergardeBouton(model.tabs.values,model.tabs.tabs2)+`
        </ul>
      </div>
    </section>`);
  },

	ongletsUI(trad,langue){
		let texte=``;
		if(trad){
			texte+=`
			<br />
			<section id="request">
      <form action="">
        <div class="form-group">
          <fieldset class="form-group">
            <div class="row align-items-end">
              <div class="col-sm-3 col-5">
                <div class="form-group">
                  <label for="selectFrom">Depuis</label>
                  <select class="custom-select" onchange="switchtrue()" id="selectFrom">
                    <option selected="selected" value="fr">Français</option>
                    <option value="en">Anglais</option>
                    <option value="es">Espagnol</option>
                  </select>
                </div>
              </div>
              <div class="form-group col-sm-1 col-2">
                <button class="btn btn-secondary" onclick="doubleswitch()" id="invButton" type="button">⇄</button>
              </div>
              <div class="col-sm-3 col-5">
                <div class="form-group">
                  <label for="selectTo">Vers</label>
                  <select class="custom-select" onchange="switchtrue()" id="selectTo">
                    <option value="fr">Français</option>
                    <option selected="selected" value="en">Anglais</option>
                    <option value="es">Espagnol</option>
                    <option value="it">Italien</option>
                    <option value="ar">Arabe</option>
                    <option value="eo">Espéranto</option>
                    <option value="ja">Japonais</option>
                    <option value="zh">Chinois</option>
                  </select>
                </div>
              </div>
              <div class="col-sm-5 col-12">
                <div class="input-group mb-3">
                  <input value="" id="expressionText" type="text" class="form-control" placeholder="Expression..." />
                  <div class="input-group-append">
                    <button class="btn btn-primary" id="tradButton" onclick="actions.traduction()" type="button">Traduire</button>
                  </div>
                </div>
              </div>
            </div>
          </fieldset>
        </div>
      </form>
    </section>
	`;
}
		texte+=`
    <section id="translations">
      <fieldset>
        <legend class="col-form-label">Traductions</legend>
        <div class="table-responsive">
          <table class="col-12 table table-sm table-bordered">
            <thead>
              <th class="align-middle text-center col-1">
                <a onclick="actions.MethodePourLeTri(1)" href="#">N°</a>
              </th>
              <th class="align-middle text-center col-1">
                <a onclick="actions.MethodePourLeTri(2)" href="#">Depuis</a>
              </th>
              <th class="align-middle text-center ">
                <a onclick="actions.MethodePourLeTri(3)" href="#">Expression</a>
              </th>
              <th class="align-middle text-center col-1">
                <a onclick="actions.MethodePourLeTri(4)" href="#">Vers</a>
              </th>
              <th class="align-middle text-center ">
                <a onclick="actions.MethodePourLeTri(5)" href="#">Traduction</a>
              </th>
              <th class="align-middle text-center col-1">
                <div class="btn-group">
                  <button id="destroy" class="btn btn-`+this.SupprimerBtnTouch(true,langue)+`"`+this.SupprimerBtnTouch(false,langue)+`>Suppr.</button>
                </div>
              </th>
            </thead>`;
		return texte;
	},

	SupprimerBtnTouch(param,langue){
		let i=0;
		while(i<structure.length&&!structure[i]){
			i++;
		}
		if(i<structure.length){
			if(param){
				return `secondary`;
			}
			return ` onclick="deleteOnep('`+langue+`')"`;
		}
		else{
			if(param){
				return `ternary`;
			}
			return ``;
		}
	},

	Lire(langue){
		if(langue=='ar'){
			return ` class="text-right"`;
		}
		return ``;
	},

	verif(ensDonnee,donnee,typeDeDonnee,aux6,langue){
		let res;
		if(langue!='trad'){
			if(typeDeDonnee=='langue'){
				if(aux6=='deb'){
					if(donnee==langue){
						res=donnee;
					}
					else{
						res=ensDonnee[2];
					}
				}
					else{
					if(donnee!=langue){
						res=donnee;
					}
					else{
						res=ensDonnee[0];
					}
				}
			}
					else{
					if(aux6=='deb'){
					if(ensDonnee[0]==langue){
						res=donnee;
					}
					else{
						res=ensDonnee[3];
					}
				}
					else{
					if(ensDonnee[2]!=langue){
						res=donnee;
					}
					else{res=ensDonnee[1];
					}
				}
			}
		}
		else{res=donnee;
		}
		return res;
				},

	Shake(num){if(structure[num]){return ` checked="true"`;
}
return ``;
},

	tableauUI(valeurs,taillePage,NumeroDePage,langue){
		let lines=``;
		let numTradPage;
		let j=0;
		let i=(NumeroDePage-1)*taillePage;
		j=0;
		while(i<valeurs.length&&i<((Number(NumeroDePage)-1)*Number(taillePage)+Number(taillePage))){
			numTradPage=j;
			if(switchnombre){
				numTradPage=valeurs.length-((Number(NumeroDePage)-1)*Number(taillePage))-1-j;
			}
			lines+=`<tr>
              <td class="text-center text-secondary"> `+valeurs[i][4]+` </td>
              <td class="text-center">
                <span class="badge badge-info">`+this.verif(valeurs[i],valeurs[i][0],'langue','deb',langue)+`</span>
              </td>
              <td`+this.Lire(this.verif(valeurs[i],valeurs[i][0],'langue','deb',langue))+`>`+this.verif(valeurs[i],valeurs[i][1],'traduction','deb',langue)+`</td>
              <td class="text-center">
                <span class="badge badge-info">`+this.verif(valeurs[i],valeurs[i][2],'langue','fin',langue)+`</span>
              </td>
              <td`+this.Lire(this.verif(valeurs[i],valeurs[i][2],'langue','fin',langue))+`>`+this.verif(valeurs[i],valeurs[i][3],'traduction','fin',langue)+`</td>
              <td class="text-center">
                <div class="form-check">
                  <input type="checkbox" id="chb`+numTradPage+`" onclick="Swappage(`+numTradPage+`)" class="form-check-input numTrad`+valeurs[i][4]+`"`+this.Shake(j)+` />
                </div>
              </td>
            </tr>
			`;j++;i++;
			}
			lines+=`<tr>
			  <td colspan="5" class="align-middle text-center"> </td>
              <td class="align-middle text-center">
                <div class="btn-group">
                  <button class="btn btn-secondary" onclick="deleteAll('`+langue+`')">Suppr. tous</button>
                </div>
              </td>
            </tr>
          </table>
        </div>`;return lines;
			},

	nombrePages(NombreDePages,NumeroDePage){
		let texte=``;
		let i=1;
		while (i<=NombreDePages){
			if(i==NumeroDePage){
				texte+=`
				<li class="page-item active">
					<a class="page-link" href="#">`+i+`</a>
				</li>`;
			}
			else{
				texte+=`
				<li class="page-item">
					<a class="page-link" onclick="switchnumpage(`+i+`)" href="#">`+i+`</a>
				</li>`;
			}
			i++;
		}
		return texte;
			},

	NumP1(NumeroDePage){
		if(NumeroDePage!=1){
			return ``;
		}
		return ` disabled`;
		},

	NumP2(NumeroDePage, NombreDePages){
		if(NumeroDePage!=NombreDePages){
			return ``;
		}
		return ` disabled`;
	},

	paginationUI(pagination){
		return `
		<section id="pagination">
          <div class="row justify-content-center">
            <nav class="col-auto">
              <ul class="pagination">
                <li class="page-item`+this.NumP1(pagination.NumeroDePage)+`">
                  <a class="page-link" onclick="switchnumpage(`+(Number(pagination.NumeroDePage)-1)+`)" href="#" tabindex="-1">Précédent</a>
                </li>`+this.nombrePages(pagination.NombreDePages,pagination.NumeroDePage)+`
                <li class="page-item`+this.NumP2(pagination.NumeroDePage,pagination.NombreDePages)+`">
                  <a class="page-link" onclick="switchnumpage(`+(Number(pagination.NumeroDePage)+1)+`)" href="#">Suivant</a>
                </li>
              </ul>
            </nav>
            <div class="col-auto">
              <div class="input-group mb-3">
                <select class="custom-select" onchange="switchpage()" id="selectPage">
                  <option value="3">3</option>
                  <option selected="selected" value="6">6</option>
                  <option value="9">9</option>
                </select>
                <div class="input-group-append">
                  <span class="input-group-text">par page</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </fieldset>
    </section>
	`;
	}
};
