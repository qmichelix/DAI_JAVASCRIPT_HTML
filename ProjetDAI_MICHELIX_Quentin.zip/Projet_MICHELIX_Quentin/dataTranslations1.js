
const translations1 = [
  ['fr','Asperge','en','Asparagus',0],
  ['ar','البرتقالي','fr','Orange',1],
  ['en','Cauliflower','fr','Chou Fleur',2],
  ['it','Pomodoro','es','Tomate',3],
];
